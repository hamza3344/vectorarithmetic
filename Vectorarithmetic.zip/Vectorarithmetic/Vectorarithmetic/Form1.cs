﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MathNet.Numerics.LinearAlgebra;

namespace Vectorarithmetic
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var V = Vector<double>.Build;
            var x = V.Random(4, 1);
            labelx.Text = x.ToString();
            var y = V.Random(4, 2);
            labely.Text = y.ToString();
            var add = x.Add(y);
            labeladd.Text = add.ToString();
            var sub = x.Subtract(y);
            labelsub.Text = sub.ToString();
            var dot = x.DotProduct(y);
            labeldot.Text = dot.ToString();
            var mul = x.Multiply(2);
            labelmul.Text = mul.ToString();
            var div = x.Divide(2);
            labeldiv.Text = div.ToString();
        }
    }
}
